export function getTechnologyList(){
    return [
        { title: 'Java' },
        { title: 'Python' },
        { title: 'React JS' },
        { title: 'React Native'},
        { title: 'Javascript' },
        { title: "Angular" },
        { title: 'Angular JS' },
        { title: 'Cypress'},
        { title: 'Docker' },
        { title: 'GO' },
        { title: 'C'},
        { title: 'Php' },
        { title: 'Wordpress' },
        { title: 'AWS'},
        { title: '.Net' },
        { title: 'SQL' },
        { title: 'MySQL'},
        { title: 'Oracle' },
        { title: 'GNode JS' },
       
    ];
}
